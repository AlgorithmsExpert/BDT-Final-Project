package miu.edu.cs523.producer;

public abstract class TwitterConfig {

//	public static final String CONSUMER_KEY = "frBsqldteXkv0fP5sNriizpfq";
//
//	public static final String CONSUMER_SECRET = "tU8fqrxgDE558Nxz5qOaYrNo9UP5GRXcMmHDQnxWRctxRb8CeF";
//
//	public static final String TOKEN  = "1573793339773784064-xeHZljv8pNLZpqLgFILnG07oeo83h1";  // ACCESS TOKEN
//
//	public static final String SECRET = "SKTmfhHeCbTUj1WhB1hTnKkLSWKRrZH2sTs6fe6NyfMiG";    //ACCESS TOKEN SECRET
	
	public static final String CONSUMER_KEY = "69wWJGAYF1QfoIUZPHIi3cOnJ";

	public static final String CONSUMER_SECRET = "WT623qzypny11VdS1gNnsEPHADRqKbaXkxEKXDGMEeq1ASknJF";

	public static final String TOKEN  = "1235044472024596480-tAeEjqy1GzKrrHhKHzOX9OE3O1MZ6N";

	public static final String SECRET = "WMxQItZR71dX0N34uF699vmpM9ucX2GevkIaYgjaTkYr0";
}
